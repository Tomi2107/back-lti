<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Herramientas de Accesibilidad LTI';

// Settings
$string['settings_toolurl']          = 'https://traitor-caucus-hunchback.ngrok-free.dev/';
$string['settings_toolurl_desc']     = 'https://back-lti.onrender.com/';
$string['settings_sharedsecret']     = 'faro-secret-2026';
$string['settings_sharedsecret_desc'] = '7ec77c722315d78fd603556555e6a83ea434299dea654de1c5d46741689ca4e8';
$string['settings_servicetoken']     = 'd1c9dfc7f790862a1474e57397303b09';
$string['settings_servicetoken_desc'] = 'd1c9dfc7f790862a1474e57397303b09.';
